/***************************************************************************************************************************************************
* Author        : S Sreedhar
* Date          : 06 Dec 2025, 14:15 PM IST
* File          : validate_ip_filenames.c
* Title         : Validate Input Filenames
* Description   :
*   This file contains functions used to validate the input files given to the
*   inverted search project. It checks for valid extensions, empty files,
*   duplicate filenames, and builds a linked list containing all valid files.
****************************************************************************************************************************************************/

#include "inverted_search.h"

int validate_ip_filenames(file_node **ipfile, char *filename[])
{
    int i = 1, ret;

    /* Validate all filenames passed from command line */
    while (filename[i] != NULL)
    {
        /* Check whether file is valid */
        if (valid_file(filename[i]) == SUCCESS)
        {
            /* Check whether file is duplicate */
            if (isdup_file(ipfile, filename[i]) == FAILURE)
            {
                /* Insert into file list */
                if (insert_ip_file(ipfile, filename[i]) == FAILURE)
                    return FAILURE;
            }
        }
        i++;
    }

    return SUCCESS;
}

/* Check if file is valid (correct extension, exists, not empty) */
int valid_file(char *file_name)
{
    /* Check file extension */
    if (strstr(file_name, ".txt") == NULL)
    {
        printf("Error: Invalid file extension\n");
        return FAILURE;
    }

    FILE *fp = fopen(file_name, "r");
    if (fp == NULL)
    {
        printf("INFO. Can't open %s file\n", file_name);
        return FAILURE;
    }

    /* Check if file is empty */
    fseek(fp, 0, SEEK_END);
    if (ftell(fp) == 0)
    {
        printf("INFO. %s file is Empty\n", file_name);
        fclose(fp);
        return MT_FILE;
    }

    fclose(fp);
    return SUCCESS;
}

/* Check if a file name is already present in the file list */
int isdup_file(file_node **head, char *file_name)
{
    file_node *temp = *head;

    while (temp != NULL)
    {
        if (strcmp(file_name, temp->file_name) == 0)
        {
            printf("INFO. %s file is Repeated\n", file_name);
            return DUP_FILE;
        }

        temp = temp->link;
    }

    return FAILURE;
}

/* Insert filename into the file list */
int insert_ip_file(file_node **head, char *ip)
{
    file_node *newnode = malloc(sizeof(file_node));
    if (newnode == NULL) return FAILURE;

    strcpy(newnode->file_name, ip);
    newnode->link = NULL;

    /* Insert first node */
    if (*head == NULL)
    {
        *head = newnode;
        return SUCCESS;
    }

    /* Insert at end of the list */
    file_node *temp = *head;
    while (temp->link != NULL)
        temp = temp->link;

    temp->link = newnode;

#ifdef DEBUG_PRINT_LIST
    file_node *temp1 = *head;
    while (temp1 != NULL)
    {
        printf("%s\n", temp1->file_name);
        temp1 = temp1->link;
    }
#endif

    return SUCCESS;
}
