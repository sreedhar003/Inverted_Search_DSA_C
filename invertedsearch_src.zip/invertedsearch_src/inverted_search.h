/***************************************************************************************************************************************************
* Author        : S Sreedhar
* Date          : 06 Dec 2025, 14:15 PM IST
* File          : inverted_search.h
* Title         : Header File for Inverted Search Project
* Description   :
*   This header file contains all the structure definitions and function
*   prototypes used in the inverted search project. The program maintains
*   an inverted index of words taken from multiple text files. Each word
*   stores its list of files along with how many times it appears in each one.
*
*   The header includes:
*       - Macros and constants
*       - Structure definitions for file nodes, main nodes, and sub nodes
*       - Function prototypes for creating, displaying, searching, saving,
*         and updating the database
***************************************************************************************************************************************************/

#ifndef INVERTED_SEARCH_H
#define INVERTED_SEARCH_H

/* Status Macros */
#define SUCCESS 1
#define FAILURE 0
#define MT_FILE -1
#define DUP_FILE 2

/* Project Constants */
#define FLENGTH 50
#define SIZE 27

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

/* Linked list node to store input file names */
typedef struct filenode {
    char file_name[FLENGTH];
    struct filenode *link;
} file_node;

/* Sub node that stores details about the files containing a specific word */
typedef struct sub_node {
    char file_name[FLENGTH];
    int w_count;           /* how many times the word appeared in the file */
    struct sub_node *link;
} sub_node;

/* Main node that stores unique words and their file lists */
typedef struct node {
    char word[FLENGTH];
    struct node *link;
    sub_node *sub_link;
    int f_count;           /* count of files in which the word appears */
} main_node;

/* Validation and input file handling */
int validate_ip_filenames(file_node **ipfile, char *filename[]);
int valid_file(char *file_name);
int isdup_file(file_node **head, char *file_name);
int insert_ip_file(file_node **head, char *ip);

/* Create database */
int create_database(file_node *filehead, main_node **head);
int read_data(main_node **head, char *file_name);
int insert_at_main(main_node **, char *, char *);
sub_node *create_sub(char *file_name);
int update_link(main_node **head, char *file_name, char *word);
int update_word_count(main_node **head, char *file_name, char *word);

int key_value(char key);
int check_word(char *word, main_node *head);
int check_file(char *file_name, char *word, main_node *head);

/* Display database */
int display_database(main_node **head);
void display_words(main_node *temp, int index);
void display_files(sub_node *temp);

/* Search functionality */
int search_database(char *word, main_node **head);

/* Save database to a file */
int save_database(char *filename, main_node **head);

/* Reload database from saved file */
int update_database(main_node **head);

#endif
