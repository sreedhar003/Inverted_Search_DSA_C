/***************************************************************************************************************************************************
* Author        : S Sreedhar
* Date          : 06 Dec 2025, 14:10 PM IST
* File          : create_database.c
* Title         : Create Database
* Description   :
*   This file contains the functions that are used to build the inverted index database.
*   The file list contains the names of all the text files that need to be processed.
*   For each file, the program reads every word, finds the hash index based on the first
*   character, and then inserts or updates the word information.
*
*   If a word appears for the first time in the database, a new main node is created.
*   If the same word appears again in the same file, its word count is increased.
*   If the word is found in a new file, a new sub node is added for that file.
****************************************************************************************************************************************************/

#include "inverted_search.h"

int create_database(file_node *filehead, main_node **head)
{
    /* Process every file in the file list */
    while (filehead != NULL)
    {
        read_data(head, filehead->file_name);
        filehead = filehead->link;
    }
    return SUCCESS;
}

int read_data(main_node **head, char *file_name)
{
    FILE *fp = fopen(file_name, "r");
    if (fp == NULL)
        return FAILURE;

    char buffer[100];
    int key, input;

    /* Read all words in the file one by one */
    while ((input = fscanf(fp, "%s", buffer)) != EOF)
    {
        if (strlen(buffer) != 0)
        {
            /* Find the index for the first character of the word */
            key = key_value(buffer[0]);

            /* Check if the word already exists in the database */
            if (check_word(buffer, head[key]) == FAILURE)
            {
                /* Word is new, so create a main node */
                insert_at_main(&head[key], buffer, file_name);
            }
            else
            {
                /* Word exists. Now check if it appears in the same file or another file */
                if (check_file(file_name, buffer, head[key]) == FAILURE)
                {
                    /* Word exists but this is a new file */
                    update_link(&head[key], buffer, file_name);
                }
                else
                {
                    /* Word exists in the same file again, so increase the count */
                    update_word_count(&head[key], buffer, file_name);
                }
            }
        }
    }

    fclose(fp);
    return SUCCESS;
}

int insert_at_main(main_node **head, char *word, char *file_name)
{
    /* Create a new main node */
    main_node *newnode = malloc(sizeof(main_node));
    if (newnode == NULL) return FAILURE;

    strcpy(newnode->word, word);
    newnode->f_count = 1;
    newnode->link = NULL;
    newnode->sub_link = create_sub(file_name);

    /* If the hash bucket is empty */
    if (*head == NULL)
    {
        *head = newnode;
        return SUCCESS;
    }

    /* Insert the node at the end of the list */
    main_node *temp = *head;
    while (temp->link != NULL)
        temp = temp->link;

    temp->link = newnode;
    return SUCCESS;
}

sub_node *create_sub(char *file_name)
{
    /* Create a new sub node containing file info */
    sub_node *newnode = malloc(sizeof(sub_node));

    strcpy(newnode->file_name, file_name);
    newnode->w_count = 1;
    newnode->link = NULL;

    return newnode;
}

int update_link(main_node **head, char *file_name, char *word)
{
    main_node *temp1 = *head;

    /* Search for the word in main list */
    while (temp1 != NULL)
    {
        if (strcmp(word, temp1->word) == 0)
        {
            sub_node *temp2 = temp1->sub_link;

            /* If no subnodes exist */
            if (temp2 == NULL)
            {
                temp1->sub_link = create_sub(file_name);
            }
            else
            {
                /* Go to the last sub node and attach a new one */
                while (temp2->link != NULL)
                    temp2 = temp2->link;

                temp2->link = create_sub(file_name);
            }

            temp1->f_count++;
            return SUCCESS;
        }

        temp1 = temp1->link;
    }

    return FAILURE;
}

int update_word_count(main_node **head, char *file_name, char *word)
{
    main_node *temp1 = *head;

    /* Traverse the main nodes */
    while (temp1 != NULL)
    {
        if (strcmp(word, temp1->word) == 0)
        {
            sub_node *temp2 = temp1->sub_link;

            /* Find the matching file node */
            while (temp2 != NULL)
            {
                if (strcmp(file_name, temp2->file_name) == 0)
                {
                    temp2->w_count++;
                    return SUCCESS;
                }
                temp2 = temp2->link;
            }
        }

        temp1 = temp1->link;
    }

    return FAILURE;
}

/* Function to return hash key based on first character */
int key_value(char key)
{
    if (isalpha(key))
    {
        key = toupper(key);
        return (key - 'A' + 1);
    }
    return 0;
}

/* Check if word exists in main node list */
int check_word(char *word, main_node *head)
{
    while (head != NULL)
    {
        if (strcmp(word, head->word) == 0)
            return SUCCESS;

        head = head->link;
    }
    return FAILURE;
}

/* Check if word exists in the same file */
int check_file(char *file_name, char *word, main_node *head)
{
    while (head != NULL)
    {
        if (strcmp(head->word, word) == 0)
        {
            sub_node *temp = head->sub_link;

            while (temp != NULL)
            {
                if (strcmp(file_name, temp->file_name) == 0)
                    return SUCCESS;

                temp = temp->link;
            }
        }

        head = head->link;
    }
    return FAILURE;
}
