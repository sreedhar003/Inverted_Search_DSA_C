/***************************************************************************************************************************************************
* Author        : S Sreedhar
* Date          : 06 Dec 2025, 14:15 PM IST
* File          : search.c
* Title         : Search Words
* Description   :
*   This file contains the function used to search a given word in the
*   inverted index database. The corresponding bucket is identified using
*   the first character of the word. Once the correct bucket is found,
*   the list is traversed to locate the matching word and display the file
*   details. If the word does not exist in that bucket, the search stops.
****************************************************************************************************************************************************/

#include "inverted_search.h"

int search_database(char *word, main_node **head)
{
    /* Determine bucket index based on first character */
    int ind = key_value(word[0]);

    /* Check if the word exists in the bucket */
    int rep = check_word(word, head[ind]);

    if (rep == SUCCESS)
    {
        /* Traverse the bucket to find the exact word */
        main_node *temp = head[ind];

        while (temp != NULL)
        {
            if (strcmp(temp->word, word) == 0)
            {
                printf("Info: Word is found in the database\n");

                /* Print file details */
                display_files(temp->sub_link);
                return SUCCESS;
            }

            temp = temp->link;
        }
    }
    else
    {
        printf("Info: Word is not present in the Database\n");
        return FAILURE;
    }
}
