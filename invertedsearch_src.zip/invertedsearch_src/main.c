/***************************************************************************************************************************************************
* Author        : S Sreedhar
* Date          : Sat 06 Dec 2025 14:10 PM IST
* File          : main.c
* Title         : Driver Function
* Description   :
*     This file contains the driver function for the Inverted Search project.
*     It provides a menu-driven interface that allows the user to:
*         1. Create a database from input text files
*         2. Display the hash table–based inverted index
*         3. Search for a word across all indexed files
*         4. Save the current database into a file
*         5. Update the database when new files are added
*
*     The driver initializes the file list, validates filenames,
*     invokes respective functionality through menu options,
*     and maintains the workflow loop.
****************************************************************************************************************************************************/

#include "inverted_search.h"

int main(int argc, char *argv[])
{
    /* Check: At least 1 file must be provided */
    if (argc < 2)
    {
        printf("ERROR: Invalid Arguments\n");
        printf("USAGE: ./a.out <file.txt> <file1.txt> ...\n");
    }

    file_node *files = NULL;     // List of valid input files
    main_node *HT[SIZE] = {NULL}; // Hash Table with 27 buckets (A-Z + misc)

    /* Validate filenames and build file list */
    validate_ip_filenames(&files, argv);

    char choice;
    int option, ret, flag = 0;  // flag ensures DB is created before saving

    do {
        /* Display menu */
        printf("┏━━━━━━━━━━━━━━━━━━━━━━┓\n");
        printf("┃1. Create Database    ┃\n");
        printf("┃2. Display Database   ┃\n");
        printf("┃3. Search Database    ┃\n");
        printf("┃4. Save Database      ┃\n");
        printf("┃5. Update Database    ┃\n");
        printf("┗━━━━━━━━━━━━━━━━━━━━━━┛\n");
        printf("Enter the operation: ");
        scanf("%d", &option);

        switch (option)
        {
            case 1:
            {
                /* Create the inverted index database only once */
                if (flag == 0)
                    ret = create_database(files, HT);

                flag = 1;
                printf("Info: Database created successfully\n");
                break;
            }

            case 2:
            {
                /* Display contents of the hash table */
                ret = display_database(HT);
                if (ret == FAILURE)
                    printf("Info: Database is empty\n");
                break;
            }

            case 3:
            {
                /* Search for a word in the inverted index */
                char wrd[50];
                printf("Enter a word to search: ");
                scanf("%49s", wrd);

                ret = search_database(wrd, HT);

                if (ret == SUCCESS)
                    printf("Info: Word searched successfully\n");

                break;
            }

            case 4:
            {
                /* Save database to a file */
                char fname[FLENGTH] = "saved_database.txt";

                if (flag == 1)
                    ret = save_database(fname, HT);
                else
                    printf("Info: Create database is mandatory before saving\n");

                if (ret == SUCCESS)
                    printf("Info: Database stored successfully\n");

                break;
            }

            case 5:
            {
                /* Update database when new files are added */
                ret = update_database(HT);

                if (ret == SUCCESS)
                    printf("Info: Database updated successfully\n");

                break;
            }

            default:
                printf("Invalid Choice\n");
        }

        /* Ask user to continue */
        printf("Do you want to continue...(Y/N): ");
        scanf(" %c", &choice);

    } while (choice == 'Y' || choice == 'y');

    return SUCCESS;
}
