/***************************************************************************************************************************************************
* Author        : S Sreedhar
* Date          : 06 Dec 2025, 14:15 PM IST
* File          : update_database.c
* Title         : Update Database
* Description   :
*   This file contains the function used to update the inverted index database
*   from a previously saved text file. The saved database contains bucket-wise
*   information such as the word, how many files the word appears in, and for
*   each file, how many times the word appeared.
*
*   The function reads this information and reconstructs the hash table by
*   inserting the words and file details back into the database structure.
****************************************************************************************************************************************************/

#include "inverted_search.h"

int update_database(main_node **head)
{
    char filename[256] = "saved_database.txt";
    int choice;

    printf("1. Load default saved_database.txt\n");
    printf("2. Enter another file name\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);
    getchar();

    /* If user wants to load a different file */
    if (choice == 2)
    {
        printf("Enter file name: ");
        scanf("%255s", filename);
        getchar();
    }

    FILE *fp = fopen(filename, "r");
    if (fp == NULL)
    {
        printf("Cannot open %s\n", filename);
        return FAILURE;
    }

    /* Check if file is empty */
    fseek(fp, 0, SEEK_END);
    if (ftell(fp) == 0)
    {
        printf("%s is empty\n", filename);
        fclose(fp);
        return FAILURE;
    }
    rewind(fp);

    /* Clear existing hash table before loading */
    for (int i = 0; i < SIZE; i++)
        head[i] = NULL;

    char line[256];
    int index, fcount;

    /* Read the saved database file line by line */
    while (fgets(line, sizeof(line), fp))
    {
        /* Identify bucket header like: #5 */
        if (line[0] != '#')
            continue;

        index = atoi(line + 1);

        /* Read the next line containing: word;file_count; */
        if (!fgets(line, sizeof(line), fp))
            break;

        char *word = strtok(line, ";");
        char *fc_str = strtok(NULL, ";");

        if (!word || !fc_str)
            continue;

        fcount = atoi(fc_str);

        /* Read the next fcount lines, each with: filename;count; */
        for (int i = 0; i < fcount; i++)
        {
            if (!fgets(line, sizeof(line), fp))
                break;

            char *fname = strtok(line, ";");
            char *cnt_str = strtok(NULL, ";");

            if (!fname || !cnt_str)
                continue;

            int wcount = atoi(cnt_str);

            /* Insert the word into the database "wcount" number of times */
            for (int j = 0; j < wcount; j++)
            {
                /* Choose whether to insert new word or update existing one */
                if (check_word(word, head[index]) == FAILURE)
                {
                    insert_at_main(&head[index], word, fname);
                }
                else if (check_file(fname, word, head[index]) == FAILURE)
                {
                    update_link(&head[index], fname, word);
                }
                else
                {
                    update_word_count(&head[index], fname, word);
                }
            }
        }

        /* Move past the ending '#' line after each bucket */
        fgets(line, sizeof(line), fp);
    }

    fclose(fp);
    return SUCCESS;
}
