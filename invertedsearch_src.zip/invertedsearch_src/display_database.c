/***************************************************************************************************************************************************
* Author        : S Sreedhar
* Date          : 06 Dec 2025 14:15:15 IST
* File          : display_output.c
* Title         : Display Database Output
* Description   :
*   This file contains the functions that print the inverted index database.
*   Every bucket in the hash table is checked, and if it contains data, all
*   the main nodes (words) and their corresponding sub nodes (file details)
*   are displayed.
*
*   Each word shows:
*       - The file count (number of files where the word appears)
*       - The list of files along with how many times the word occurred
*
****************************************************************************************************************************************************/

#include "inverted_search.h"

int display_database(main_node **head)
{
    int i = 0, flag = 0;

    printf("\n==================== INVERTED INDEX DATABASE ====================\n");

    /* Loop through all 27 buckets */
    while (i < 27)
    {
        /* Only print buckets that contain data */
        if (head[i] != NULL)
        {
            printf("\nBucket %d:\n", i);
            printf("---------------------------------------------------------------\n");

            /* Print all words inside this bucket */
            display_words(head[i], i);

            flag = 1;   // At least one bucket has data
        }
        i++;
    }

    printf("\n========================== END OF DATABASE ========================\n");

    /* If flag is 0, database is empty */
    if (flag == 0)
        return FAILURE;
    else
        return SUCCESS;
}

void display_words(main_node *temp, int index)
{
    /* Print each word node inside the bucket */
    while (temp != NULL)
    {
        printf("[%d]   [ %-10s ]   %d file/s:", index, temp->word, temp->f_count);

        /* Print the sub-node list for this word */
        display_files(temp->sub_link);

        temp = temp->link;
    }
}

void display_files(sub_node *temp)
{
    /* Print each file name and word count */
    while (temp != NULL)
    {
        printf(" File : %-10s %d", temp->file_name, temp->w_count);
        temp = temp->link;
    }
}
