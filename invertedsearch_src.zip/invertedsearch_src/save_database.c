/***************************************************************************************************************************************************
* Author        : S Sreedhar
* Date          : 06 Dec 2025, 14:15 PM IST
* File          : save_database.c
* Title         : Save Database
* Description   :
*   This file contains the function that stores the current inverted index
*   database into a text file. The data is written bucket by bucket. For every
*   word, the file count and the list of files in which the word appears are
*   written. This saved file can later be loaded again using update_database().
****************************************************************************************************************************************************/

#include "inverted_search.h"

int save_database(char *filename, main_node **head)
{
    FILE *fp = fopen(filename, "w");
    if (fp == NULL)
    {
        printf("Error: Unable to open the file\n");
        return FAILURE;
    }

    /* Traverse through all buckets */
    for (int i = 0; i < SIZE; i++)
    {
        main_node *temp = head[i];

        /* Process each word in the bucket */
        while (temp != NULL)
        {
            /* Write bucket index for this word */
            fprintf(fp, "#%d;\n", i);

            /* Write word and number of files in which it appears */
            fprintf(fp, "%s;%d;\n", temp->word, temp->f_count);

            /* Write file wise details */
            sub_node *temp1 = temp->sub_link;
            while (temp1 != NULL)
            {
                fprintf(fp, "%s;%d;\n", temp1->file_name, temp1->w_count);
                temp1 = temp1->link;
            }

            /* Mark end of block for this word */
            fprintf(fp, "#\n");

            temp = temp->link;
        }
    }

    fclose(fp);
    return SUCCESS;
}
